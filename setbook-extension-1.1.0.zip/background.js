/* SetBook Scraper background service worker (Manifest V3).
   Clicking the toolbar icon scrapes the active tab's text with the content
   script (activeTab grants one-shot access — no broad host permissions),
   then delivers it to the SetBook app tab by dispatching the
   `setbook-url-import` event the app already listens for. The app opens its
   mass-entry editor with the scraped text.

   The SetBook tab may be the live site OR a local file copy of the app
   (handy when testing a new build). Local file tabs need "Allow access to
   file URLs" enabled for the extension on chrome://extensions — Chrome
   gates all file:// scripting behind that switch. A file tab is only
   trusted as SetBook after a DOM probe confirms it really is the app
   (title + a known element id); when several SetBook tabs are open, the
   most recently used one wins.

   Self-update: unpacked extensions don't auto-update, so the worker checks
   ext-version.json on the SetBook site whenever the icon is clicked, on
   install, and whenever a SetBook tab finishes loading. When a newer
   version exists it injects a gold banner into the SetBook tab (dismissal
   is tracked per version in the page's own localStorage). */
const SETBOOK_URL = 'https://max-levi.github.io/SetBook/';
const SETBOOK_HTTPS_MATCH = 'https://max-levi.github.io/SetBook/*';
const TAB_QUERY_URLS = [SETBOOK_HTTPS_MATCH, 'file:///*'];
const SETBOOK_RE = /^https:\/\/max-levi\.github\.io\/SetBook\//i;
const UPDATE_URL = 'https://max-levi.github.io/SetBook/ext-version.json';
const DISMISS_KEY = 'setbook-ext-update-dismissed';
const VER_RE = /^\d+\.\d+\.\d+$/;

function isScrapableUrl(url){ return /^(https?|file):/i.test(url || ''); }
function isSetBookUrl(url){ return SETBOOK_RE.test(url || '') || /^file:/i.test(url || ''); }
function cmpVersions(a, b){
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++){
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

/* DOM probe: is this tab really the SetBook app? Used for file:// tabs,
   which are never trusted by URL alone. Rejects (→ false) when the
   extension has no access — e.g. file URLs without the toggle enabled. */
async function tabLooksLikeSetBook(tabId){
  try {
    const rs = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => (document.title || '').indexOf('SetBook') !== -1 &&
                   !!document.getElementById('filtersToggle'),
    });
    return !!(rs && rs[0] && rs[0].result);
  } catch (e){ return false; }
}

async function activeTabIsSetBook(tab){
  if (!tab || !tab.id) return false;
  const url = tab.url || '';
  if (SETBOOK_RE.test(url)) return true; // live site: trusted by URL
  if (!/^file:/i.test(url)) return false;
  return tabLooksLikeSetBook(tab.id); // local copy: verify by probe
}

async function findSetBookTab(){
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: TAB_QUERY_URLS }) || []; } catch (e){ tabs = []; }
  const verified = [];
  for (const t of tabs){
    if (!t || !t.id) continue;
    const url = t.url || '';
    if (SETBOOK_RE.test(url)) verified.push(t); // live site: trusted by URL
    else if (url && /^file:/i.test(url) && await tabLooksLikeSetBook(t.id)) verified.push(t);
  }
  // Most recently used SetBook tab wins (e.g. the local copy under test).
  verified.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  return verified.length ? verified[0] : null;
}

/* Focus the existing SetBook tab, or open the live site and wait until it
   loads. Returns { tab, created } so callers know when we fell back. */
async function openSetBookTab(){
  let tab = null;
  try { tab = await findSetBookTab(); } catch (e) { tab = null; }
  if (tab){ await chrome.tabs.update(tab.id, { active: true }).catch(() => {}); return { tab, created: false }; }
  tab = await chrome.tabs.create({ url: SETBOOK_URL, active: true });
  await new Promise((resolve) => {
    const done = () => { chrome.tabs.onUpdated.removeListener(listener); resolve(); };
    const listener = (tabId, info) => { if (tabId === tab.id && info.status === 'complete') done(); };
    chrome.tabs.onUpdated.addListener(listener);
    setTimeout(done, 15000);
  });
  return { tab, created: true };
}

/* Nudge toward the file-access switch, once per session, when we had to
   fall back to the live site and local files are unreachable. */
let fileAccessTipShown = false;
async function maybeFileAccessTip(tabId){
  if (fileAccessTipShown) return;
  fileAccessTipShown = true;
  let allowed = true;
  try { allowed = await chrome.extension.isAllowedFileSchemeAccess(); } catch (e){}
  if (!allowed){
    await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: () => { if (window.showToast) window.showToast('Sent to the live SetBook site. To deliver to a local file copy instead, enable "Allow access to file URLs" for SetBook Scraper in chrome://extensions.'); }
    }).catch(() => {});
  }
}

async function sendTextToSetBook(text){
  const opened = await openSetBookTab();
  await chrome.scripting.executeScript({
    target: { tabId: opened.tab.id },
    world: 'MAIN',
    func: (t) => window.dispatchEvent(new CustomEvent('setbook-url-import', { detail: { text: t } })),
    args: [text]
  });
  if (opened.created) await maybeFileAccessTip(opened.tab.id);
}

async function maybeShowUpdateBanner(){
  let info;
  try {
    const res = await fetch(UPDATE_URL, { cache: 'no-store' });
    if (!res.ok) return;
    info = await res.json();
  } catch (e){ return; } // offline or not yet published — stay silent
  const latest = info && info.version;
  const current = chrome.runtime.getManifest().version;
  if (!latest || !VER_RE.test(latest) || !VER_RE.test(current)) return;
  if (cmpVersions(latest, current) <= 0) return;
  // The download URL is only ever opened via window.open in the banner, which
  // scheme-gates it; still, keep the payload tight here.
  const download = typeof info.download === 'string' && /^https:/i.test(info.download)
    ? info.download : '';
  let tab = null;
  try { tab = await findSetBookTab(); } catch (e) { tab = null; }
  if (!tab) return; // no SetBook tab open — nothing to banner into
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['update-banner.js'], world: 'MAIN' });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: (opts) => { if (window.__setbookShowUpdateBanner) window.__setbookShowUpdateBanner(opts); },
      args: [{ current, latest, download, dismissKey: DISMISS_KEY }]
    });
  } catch (e){ /* tab went away — harmless */ }
}

chrome.action.onClicked.addListener(async (tab) => {
  const url = (tab && tab.url) || '';
  if (tab && tab.id && await activeTabIsSetBook(tab)){
    // Clicked while on the SetBook tab itself: nothing to scrape here.
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: () => { if (window.showToast) window.showToast('Open the page with the lyrics first, then click the SetBook icon.'); }
    }).catch(() => {});
  } else if (tab && tab.id && isScrapableUrl(url)){
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['extractor.js']
      });
      const text = results && results[0] && results[0].result && results[0].result.text;
      // Even empty text goes through: the app toasts "The extension sent no text."
      await sendTextToSetBook(text || '');
    } catch (e){
      // Some pages (e.g. the Chrome Web Store) block extension injection.
    }
  }
  await maybeShowUpdateBanner();
});

chrome.runtime.onInstalled.addListener(() => { maybeShowUpdateBanner(); });
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== 'complete' || !tab || !tab.id) return;
  const url = tab.url || '';
  if (SETBOOK_RE.test(url)) maybeShowUpdateBanner();
  // Local file copies: only check after the probe confirms it's SetBook.
  else if (/^file:/i.test(url)) tabLooksLikeSetBook(tabId).then((ok) => { if (ok) maybeShowUpdateBanner(); });
});
