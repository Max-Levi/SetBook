/* SetBook Scraper background service worker (Manifest V3).
   Clicking the toolbar icon scrapes the active tab's text with the content
   script (activeTab grants one-shot access — no broad host permissions),
   then delivers it to the SetBook web app tab by dispatching the
   `setbook-url-import` event the app already listens for. The app opens its
   mass-entry editor with the scraped text.

   Self-update: unpacked extensions don't auto-update, so the worker checks
   ext-version.json on the SetBook site whenever the icon is clicked, on
   install, and whenever a SetBook tab finishes loading. When a newer
   version exists it injects a gold banner into the SetBook tab (dismissal
   is tracked per version in the page's own localStorage). */
const SETBOOK_URL = 'https://max-levi.github.io/SetBook/';
const SETBOOK_MATCH = 'https://max-levi.github.io/SetBook/*';
const SETBOOK_RE = /^https:\/\/max-levi\.github\.io\/SetBook\//i;
const UPDATE_URL = 'https://max-levi.github.io/SetBook/ext-version.json';
const DISMISS_KEY = 'setbook-ext-update-dismissed';
const VER_RE = /^\d+\.\d+\.\d+$/;

function isScrapableUrl(url){ return /^(https?|file):/i.test(url || ''); }
function isSetBookUrl(url){ return SETBOOK_RE.test(url || ''); }
function cmpVersions(a, b){
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++){
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

async function findSetBookTab(){
  const tabs = await chrome.tabs.query({ url: SETBOOK_MATCH });
  return tabs && tabs[0] ? tabs[0] : null;
}

/* Focus the existing SetBook tab, or open one and wait until it loads. */
async function openSetBookTab(){
  let tab = null;
  try { tab = await findSetBookTab(); } catch (e) { tab = null; }
  if (tab){ await chrome.tabs.update(tab.id, { active: true }).catch(() => {}); return tab; }
  tab = await chrome.tabs.create({ url: SETBOOK_URL, active: true });
  await new Promise((resolve) => {
    const done = () => { chrome.tabs.onUpdated.removeListener(listener); resolve(); };
    const listener = (tabId, info) => { if (tabId === tab.id && info.status === 'complete') done(); };
    chrome.tabs.onUpdated.addListener(listener);
    setTimeout(done, 15000);
  });
  return tab;
}

async function sendTextToSetBook(text){
  const tab = await openSetBookTab();
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: 'MAIN',
    func: (t) => window.dispatchEvent(new CustomEvent('setbook-url-import', { detail: { text: t } })),
    args: [text]
  });
}

async function maybeShowUpdateBanner(){
  let info;
  try {
    const res = await fetch(UPDATE_URL, { cache: 'no-store' });
    if (!res.ok) return;
    info = await res.json();
  } catch (e){ return; } // offline or not yet published — stay silent
  const latest = info && info.version;
  const current = chrome.runtime.getManifest().version;
  if (!latest || !VER_RE.test(latest) || !VER_RE.test(current)) return;
  if (cmpVersions(latest, current) <= 0) return;
  // The download URL is only ever opened via window.open in the banner, which
  // scheme-gates it; still, keep the payload tight here.
  const download = typeof info.download === 'string' && /^https:/i.test(info.download)
    ? info.download : '';
  let tab = null;
  try { tab = await findSetBookTab(); } catch (e) { tab = null; }
  if (!tab) return; // no SetBook tab open — nothing to banner into
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['update-banner.js'], world: 'MAIN' });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: (opts) => { if (window.__setbookShowUpdateBanner) window.__setbookShowUpdateBanner(opts); },
      args: [{ current, latest, download, dismissKey: DISMISS_KEY }]
    });
  } catch (e){ /* tab went away — harmless */ }
}

chrome.action.onClicked.addListener(async (tab) => {
  const url = (tab && tab.url) || '';
  if (tab && tab.id && isSetBookUrl(url)){
    // Clicked while on the SetBook tab itself: nothing to scrape here.
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: () => { if (window.showToast) window.showToast('Open the page with the lyrics first, then click the SetBook icon.'); }
    }).catch(() => {});
  } else if (tab && tab.id && isScrapableUrl(url)){
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['extractor.js']
      });
      const text = results && results[0] && results[0].result && results[0].result.text;
      // Even empty text goes through: the app toasts "The extension sent no text."
      await sendTextToSetBook(text || '');
    } catch (e){
      // Some pages (e.g. the Chrome Web Store) block extension injection.
    }
  }
  await maybeShowUpdateBanner();
});

chrome.runtime.onInstalled.addListener(() => { maybeShowUpdateBanner(); });
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === 'complete' && isSetBookUrl(tab && tab.url)) maybeShowUpdateBanner();
});
