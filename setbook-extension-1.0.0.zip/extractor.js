/* SetBook Scraper content script — runs in the page's own tab, so it reads the
   live DOM directly: no CORS fetch. Mirrors the web app's extractTextFromHtml
   rules (non-content elements dropped, block elements and <br> become line
   breaks). Returns plain text only. */
(() => {
  const BLOCK = new Set(['P','DIV','LI','TR','H1','H2','H3','H4','H5','H6','PRE',
    'BLOCKQUOTE','SECTION','ARTICLE','HR','TABLE','UL','OL','DT','DD','FIGCAPTION']);
  const SKIP = /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|NAV|HEADER|FOOTER|ASIDE|FORM|IFRAME)$/;
  const out = [];
  const walk = (node) => {
    node.childNodes.forEach(ch => {
      if (ch.nodeType === 3){ out.push(ch.textContent); }
      else if (ch.nodeType === 1){
        if (SKIP.test(ch.tagName)) return;
        if (ch.tagName === 'BR'){ out.push('\n'); return; }
        const block = BLOCK.has(ch.tagName);
        if (block) out.push('\n');
        walk(ch);
        if (block) out.push('\n');
      }
    });
  };
  walk(document.body || document.documentElement);
  const text = out.join('')
    .split('\n')
    .map(l => l.replace(/[ \t\u00a0]+$/, ''))
    .join('\n')
    .replace(/^\n+|\n+$/g, '')
    .replace(/\n{3,}/g, '\n\n');
  return { text };
})();
