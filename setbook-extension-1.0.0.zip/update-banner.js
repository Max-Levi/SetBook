/* SetBook Scraper update banner — injected into the SetBook web app tab (MAIN
   world, so no chrome.* APIs) when a newer extension version exists.
   Dismissal is tracked per version in the page's own localStorage, mirroring
   the ComicSaver web app's self-update flow. All strings are built with
   textContent — the only outside input is the version pair, validated as
   plain dotted numbers before this ever runs. */
window.__setbookShowUpdateBanner = function(opts){
  try {
    const current = opts && opts.current, latest = opts && opts.latest;
    const download = opts && opts.download, dismissKey = opts && opts.dismissKey;
    if (!current || !latest || !dismissKey) return;
    if (document.getElementById('setbookExtUpdateBanner')) return;
    if (window.localStorage.getItem(dismissKey) === latest) return;

    const css = document.createElement('style');
    css.textContent = [
      '#setbookExtUpdateBanner{position:fixed;top:0;left:0;right:0;z-index:99999;',
      'background:#b98a1d;color:#fff;padding:10px 16px;display:flex;gap:12px;',
      'align-items:center;justify-content:center;flex-wrap:wrap;',
      'font:14px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif;}',
      '#setbookExtUpdateBanner .seub-actions{display:flex;gap:8px;flex-wrap:wrap;}',
      '#setbookExtUpdateBanner button{border:1px solid rgba(255,255,255,.7);border-radius:8px;',
      'padding:8px 14px;min-height:44px;font-size:14px;cursor:pointer;}',
      '#setbookExtUpdateBanner .seub-dl{background:#fff;color:#7a5c10;font-weight:700;border-color:#fff;}',
      '#setbookExtUpdateBanner .seub-ghost{background:transparent;color:#fff;}',
      '#setbookExtUpdateModal{position:fixed;inset:0;z-index:100000;display:none;',
      'align-items:center;justify-content:center;background:rgba(0,0,0,.45);padding:16px;}',
      '#setbookExtUpdateModal.open{display:flex;}',
      '#setbookExtUpdateModal .seum-card{background:#fff;color:#222;border-radius:12px;',
      'max-width:520px;width:100%;max-height:86vh;overflow:auto;padding:20px 22px;',
      'font:14px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif;}',
      '#setbookExtUpdateModal h2{margin:0 0 10px;font-size:18px;}',
      '#setbookExtUpdateModal ol{margin:0 0 14px;padding-left:22px;}',
      '#setbookExtUpdateModal li{margin-bottom:8px;}',
      '#setbookExtUpdateModal code{background:#f0ede4;padding:1px 6px;border-radius:4px;}',
      '#setbookExtUpdateModal .seum-close{margin-top:4px;padding:10px 18px;min-height:44px;',
      'border-radius:8px;border:1px solid #ccc;background:#f5f2ea;cursor:pointer;font-size:14px;}'
    ].join('\n');
    document.head.appendChild(css);

    const banner = document.createElement('div');
    banner.id = 'setbookExtUpdateBanner';
    const msg = document.createElement('div');
    const strong = document.createElement('strong');
    strong.textContent = 'SetBook scraper ' + latest + ' is available';
    msg.appendChild(strong);
    const rest = document.createElement('span');
    rest.textContent = " — you're running " + current + '.';
    msg.appendChild(rest);
    banner.appendChild(msg);

    const actions = document.createElement('div');
    actions.className = 'seub-actions';
    const dlBtn = document.createElement('button');
    dlBtn.className = 'seub-dl';
    dlBtn.textContent = 'Download';
    const howBtn = document.createElement('button');
    howBtn.className = 'seub-ghost';
    howBtn.textContent = 'How to update';
    const disBtn = document.createElement('button');
    disBtn.className = 'seub-ghost';
    disBtn.textContent = 'Dismiss';
    actions.appendChild(dlBtn);
    actions.appendChild(howBtn);
    actions.appendChild(disBtn);
    banner.appendChild(actions);
    document.body.appendChild(banner);

    const modal = document.createElement('div');
    modal.id = 'setbookExtUpdateModal';
    const card = document.createElement('div');
    card.className = 'seum-card';
    const h2 = document.createElement('h2');
    h2.textContent = 'Update the SetBook scraper';
    card.appendChild(h2);
    const ol = document.createElement('ol');
    [
      ['Download the zip with the button above (or again from the banner).', []],
      ['Find the folder you installed the extension into — update the ', ['same', ' folder so your setup survives.']],
      ['Empty that folder, then unzip the new version into it.', []],
      ['Open ', ['chrome://extensions', ' (type it — pages can\u2019t open chrome:// links) and press Reload on SetBook Scraper.']],
      ['Reopen SetBook — when the banner is gone, you\u2019re up to date.', []]
    ].forEach(([pre, mid]) => {
      const li = document.createElement('li');
      if (!mid.length){ li.textContent = pre; }
      else {
        li.appendChild(document.createTextNode(pre));
        const code = document.createElement('code');
        code.textContent = mid[0];
        li.appendChild(code);
        li.appendChild(document.createTextNode(mid[1]));
      }
      ol.appendChild(li);
    });
    card.appendChild(ol);
    const closeBtn = document.createElement('button');
    closeBtn.className = 'seum-close';
    closeBtn.textContent = 'Close';
    closeBtn.addEventListener('click', () => modal.classList.remove('open'));
    card.appendChild(closeBtn);
    modal.appendChild(card);
    modal.addEventListener('click', (e) => { if (e.target === modal) modal.classList.remove('open'); });
    document.body.appendChild(modal);

    dlBtn.addEventListener('click', () => {
      // Scheme-gated: the URL comes from ext-version.json on our own site,
      // but a download link has no business being anything but https.
      if (download && /^https:/i.test(download)) window.open(download, '_blank', 'noopener');
    });
    howBtn.addEventListener('click', () => modal.classList.add('open'));
    disBtn.addEventListener('click', () => {
      try { window.localStorage.setItem(dismissKey, latest); } catch (e){}
      banner.remove();
      modal.remove();
      css.remove();
    });
  } catch (e){ /* never break the host page */ }
};
